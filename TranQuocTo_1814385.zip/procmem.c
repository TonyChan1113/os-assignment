#include "procmem.h"
#include <linux/kernel.h>
#include <sys/syscall.h>

long get_proc_info(pid_t pid, struct proc_segs *info) {
	return syscall(546, pid, info);
}
